<?php
class NoTestCaseClass
{
}
?>