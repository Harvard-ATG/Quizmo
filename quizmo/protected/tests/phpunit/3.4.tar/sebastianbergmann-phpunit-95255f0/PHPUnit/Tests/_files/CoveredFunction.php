<?php
function global_function()
{
    $a = 1 + 2;
}
